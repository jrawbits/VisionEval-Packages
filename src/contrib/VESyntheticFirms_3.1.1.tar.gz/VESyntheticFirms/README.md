# VESyntheticFirms
VisionEval Synthetic Firms module

See [Getting Started](https://github.com/VisionEval/VisionEval/wiki/Getting-Started)
