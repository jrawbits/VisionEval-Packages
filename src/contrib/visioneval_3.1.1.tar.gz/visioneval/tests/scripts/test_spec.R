TestSpec_ls <-
  list(
    NAME = "Azone",
    TABLE = "Azone",
    GROUP = "Year",
    TYPE = "character",
    UNITS = "none",
    NAVALUE = "",
    SIZE = 3,
    PROHIBIT = c("NA"),
    ISELEMENTOF = ""
  )
